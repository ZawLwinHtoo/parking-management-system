export const SIDEBAR_WIDTH = 280; // keep in one place
