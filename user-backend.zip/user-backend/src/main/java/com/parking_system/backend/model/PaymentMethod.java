package com.parking_system.backend.model;

public enum PaymentMethod {
    CASH, CARD, WALLET
}
