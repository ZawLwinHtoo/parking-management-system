package com.parking_system.backend.dto;

public class PaymentRequest {
    private Integer parkedId;
    public Integer getParkedId() { return parkedId; }
    public void setParkedId(Integer parkedId) { this.parkedId = parkedId; }
}
