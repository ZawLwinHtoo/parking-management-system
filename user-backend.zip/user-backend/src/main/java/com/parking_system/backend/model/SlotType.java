package com.parking_system.backend.model;

public enum SlotType {
    SMALL, MEDIUM, LARGE
}
