package com.parking_system.backend.dto;

import lombok.Data;

@Data
public class UnparkRequest {
    private String carNumber;
}