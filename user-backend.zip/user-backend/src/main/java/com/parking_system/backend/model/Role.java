package com.parking_system.backend.model;

public enum Role {
    ADMIN, USER
}
